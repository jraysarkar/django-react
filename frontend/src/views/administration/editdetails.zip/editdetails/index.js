import { Fragment } from 'react'
import { Row, Col } from 'reactstrap'
import Breadcrumbs from '@components/breadcrumbs'
import VerticalForm from './VerticalForm'


const Editdetails = () => {
  return (
    <Fragment>
      <Row>
        <Col md='6' sm='12'>
        <VerticalForm /> 
        </Col>
        <Col md='6' sm='12'>
         
        </Col>
      </Row>
    </Fragment>
  )
}
export default Editdetails
